var HnameArray = []
var HjerseyArray = []
var HpositionArray = []

var AnameArray = []
var AjerseyArray = []
var ApositionArray = []

var gameid
var gamedate
var homeT
var awayT

var fname
var lname
var name
var position
var number
var jersey

var idArray = []
var dateArray = []
var hArray = []
var aArray = []



var url = "http://localhost:8000";   // The URL and the port number must match the server-side
var endpoint = "/GameFiles/team-Info.json";
var http = new XMLHttpRequest();
http.open("GET", url+endpoint, true);
http.onreadystatechange = function() {
    var DONE = 4;       // 4 means the request is done.
    var OK = 200;       // 200 means a successful return.
    if (http.readyState == DONE && http.status == OK && http.responseText) {
        // JSON string
        replyString = http.responseText;
        // convert JSON string into JavaScript object
        replyObj = JSON.parse(replyString);

       var fileLength = replyObj.length;
       document.getElementById("size").innerHTML = fileLength;

       for (var i = 0; i<= fileLength - 1; i++)
       {
            gameid = replyObj[i]["game id"];
            gamedate = replyObj[i]["game date"];
            homeT = replyObj[i]["home team"];
            awayT = replyObj[i]["away team"];

            idArray.push(gameid);
            dateArray.push(gamedate);
            hArray.push(homeT);
            aArray.push(awayT);
       }
    }
    document.getElementById("idArray").innerHTML = idArray;
    document.getElementById("dateArray").innerHTML = dateArray;
    document.getElementById("hArray").innerHTML = hArray;
    document.getElementById("aArray").innerHTML = aArray;

};
    // Send request
http.send();



/*

for (var i = 0; i <= fileLength - 1; i++)
        {
            gameid = replyObj[i]["game id"]
            gamedate = replyObj[i]["game date"]
            homeT = replyObj[i]["home team"]
            awayT = replyObj[i]["away team"]

            idArray.push(gameid)
            dateArray.push(gamedate)
            hArray.push(homeT)
            aArray.push(awayT)
        }
document.getElementById("idArray").innerHTML = idArray;

document.getElementById("id"+i).innerHTML = parseInt(gameid)
document.getElementById("gameDate"+i).innerHTML = String(gamedate)
document.getElementById("hTeam"+i).innerHTML = String(homeT)
document.getElementById("aTeam"+i).innerHTML = String(awayT)

document.getElementById("idArray").innerHTML = idArray
document.getElementById("dateArray").innerHTML = dateArray
document.getElementById("homeArray").innerHTML = hArray
document.getElementById("awayArray").innerHTML = aArray

function getEvents()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);

            var allEvents = JSON.stringify(replyObj.events)         //Gives error when ran(think file is too big)
            var events = JSON.stringify(replyObj.events[1])         //Event 0 holds game info, moments
            var moments = JSON.stringify(replyObj.events[1].moments)

            document.getElementById("e1").innerHTML = "Event #2: " + events
            document.getElementById("m1").innerHTML = "All moments for E2: " + moments
        }
    };
    // Send request
    http.send();
}

function getShots()
{
    window.location.href = "/ShotList3.html"
}

function game()
{
    window.location.href = "/Game.html"
}

function getJump()
{
    window.location.href = "JumpList3.html"
}

function getAir()
{
    window.location.href = "AirList.html"
}
function createTable()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText)
        {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);
            gameid2 = replyObj.gameid
            gamedate2 = replyObj.gamedate
            homeT2 = replyObj.events[0].home.name
            awayT2 = replyObj.events[0].visitor.name
            var tbl = document.createElement('table');
            var row = tbl.insertRow(0);
            var cell = row.insertCell(0);
            cell.innerHTML = "Game ID";
            cell = row.insertCell(1);
            cell.innerHTML = "Game Date";
            cell = row.insertCell(2);
            cell.innerHTML = "Home Team";
            cell = row.insertCell(3);
            cell.innerHTML = "Away Team";
            cell.style.textAlign = "right";

            row = tbl.insertRow(0);
            row.className = "results_row";
            cell = row.insertCell(0);
            cell.innerHTML = gameid2;
            cell = row.insertCell(1);
            cell.innerHTML = gamedate2;
            cell = row.insertCell(2);
            cell.innerHTML = homeT2;
            cell = row.insertCell(3);
            cell.innerHTML = awayT2;
            cell = row.insertCell(4);
            cell.innerHTML = parseFloat(obj[i].Price).toFixed(2);
            cell.style.textAlign = "right";
            row.addEventListener("click", (function(){ alert('click'); }));

            return tbl

        }
    };
    http.send();
}
function getDirectory()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/GameFiles";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);



            document.getElementById("files").innerHTML = "Files under directory: " + files

        }
    };
    // Send request
    http.send();
}
function getJSON()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/GameFiles";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);



            document.getElementById("file").innerHTML = 0021500025.json

        }
    };
    // Send request
    http.send();
}



function awayTable() {
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500032.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);


            var visplayers = JSON.stringify(replyObj.events[0].visitor.players)
            document.getElementById("visPlayers").innerHTML = visplayers

            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var firstname = (replyObj.events[0].visitor.players[i].firstname)
                var lastname = (replyObj.events[0].visitor.players[i].lastname)
                var name = firstname + " " + lastname
                AnameArray.push(name)
            }
            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var jersey = (replyObj.events[0].visitor.players[i].jersey)
                AjerseyArray.push(jersey)
            }
            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var pos = (replyObj.events[0].visitor.players[i].position)
                ApositionArray.push(pos)
            }
            var body = document.getElementsByTagName('body')[0];
            var tbl = document.createElement('table');
            tbl.style.width = '100%';
            tbl.setAttribute('border', '5');
            tbl.setAttribute('cellpadding', '4');
            tbl.setAttribute('cellspacing', '5');;

            var h1 = document.createElement('th');
            h1.appendChild(document.createTextNode("Name));
            h1.setAttribute('bgcolor', '##b0e0e6')
            var h2 = document.createElement('th');
            h2.appendChild(document.createTextNode("Position"));
            h2.setAttribute('bgcolor', '##b0e0e6')
            var h3 = document.createElement('th');
            h3.appendChild(document.createTextNode("Number"));
            h3.setAttribute('bgcolor', '##b0e0e6')


            var tbdy = document.createElement('tbody');
            for (var i = 0; i < AnameArray.length - 1; i++) {
                var tr = document.createElement('tr');
                var td1 = document.createElement('td');
                td1.setAttribute('bgcolor', '#ffffff')
                td1.appendChild(document.createTextNode(AnameArray[i]))
                var td2 = document.createElement('td');
                td2.setAttribute('bgcolor', '#ffffff')
                td2.appendChild(document.createTextNode(ApositionArray[i]))
                var td3 = document.createElement('td');
                td3.setAttribute('bgcolor', '#ffffff')
                td3.appendChild(document.createTextNode(AjerseyArray[i]))

                tr.appendChild(td1)
                tr.appendChild(td2)
                tr.appendChild(td3)
                tbdy.appendChild(tr);
            }
            tbl.appendChild(h1)
            tbl.appendChild(h2)
            tbl.appendChild(h3)
            tbl.appendChild(tbdy)
            body.appendChild(tbl)
            }
        };
        http.send();
}
function createTable()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText)
        {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);
            gameid = replyObj.gameid
            gamedate = replyObj.gamedate
            homeT = replyObj.events[0].home.name
            awayT = replyObj.events[0].visitor.name
            var tbl = document.createElement('table');
            var row = tbl.insertRow(0);
            var cell = row.insertCell(0);
            cell.innerHTML = "Game ID";
            cell = row.insertCell(1);
            cell.innerHTML = "Game Date";
            cell = row.insertCell(2);
            cell.innerHTML = "Home Team";
            cell = row.insertCell(3);
            cell.innerHTML = "Away Team";
            cell.style.textAlign = "right";

            row = tbl.insertRow(0);
            row.className = "results_row";
            cell = row.insertCell(0);
            cell.innerHTML = gameid;
            cell = row.insertCell(1);
            cell.innerHTML = gamedate;
            cell = row.insertCell(2);
            cell.innerHTML = homeT;
            cell = row.insertCell(3);
            cell.innerHTML = awayT;
            cell = row.insertCell(4);
            cell.innerHTML = parseFloat(obj[i].Price).toFixed(2);
            cell.style.textAlign = "right";
            row.addEventListener("click", (function(){ alert('click'); }));

            return tbl

        }
    };
    http.send();
}

document.getElementById('test').appendChild(createTable());

function gameTable() {
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText)
        {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);

            gameid = replyObj.gameid
            gamedate = replyObj.gamedate
            homeT = replyObj.events[0].home.name
            awayT = replyObj.events[0].visitor.name
            var body = document.getElementsByTagName('body')[0];
            var tbl = document.createElement('table');
            tbl.style.width = '100%';
            tbl.setAttribute('border', '5');
            tbl.setAttribute('cellpadding', '4');
            tbl.setAttribute('cellspacing', '5');;

            var h1 = document.createElement('th');
            h1.appendChild(document.createTextNode("Game ID));
            h1.setAttribute('bgcolor', '##b0e0e6')
            var h2 = document.createElement('th');
            h2.appendChild(document.createTextNode("Game Date"));
            h2.setAttribute('bgcolor', '##b0e0e6')
            var h3 = document.createElement('th');
            h3.appendChild(document.createTextNode("Home Team"));
            h3.setAttribute('bgcolor', '##b0e0e6')
            var h4 = document.createElement('th');
            h4.appendChild(document.createTextNode("Away Team"));
            h4.setAttribute('bgcolor', '##b0e0e6')


            var tbdy = document.createElement('tbody');

            var tr = document.createElement('tr');
            var td1 = document.createElement('td');
            td1.setAttribute('bgcolor', '#ffffff')
            td1.appendChild(document.createTextNode(gameid))
            var td2 = document.createElement('td');
            td2.setAttribute('bgcolor', '#ffffff')
            td2.appendChild(document.createTextNode(gamedate))
            var td3 = document.createElement('td');
            td3.setAttribute('bgcolor', '#ffffff')
            td3.appendChild(document.createTextNode(homeT))
            var td4 = document.createElement('td');
            td4.setAttribute('bgcolor', '#ffffff')
            td4.appendChild(document.createTextNode(awayT))

            tr.appendChild(td1)
            tr.appendChild(td2)
            tr.appendChild(td3)
            tr.appendChild(td4)
            tbdy.appendChild(tr);

            tbl.appendChild(h1)
            tbl.appendChild(h2)
            tbl.appendChild(h3)
            tbl.appendChild(h4)
            tbl.appendChild(tbdy)
            body.appendChild(tbl)

            document.getElementById("gameTable").innerHTML = tbl
        }
    };
    http.send();
}
function getGameDetails()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);

            gameid = replyObj.gameid
            gamedate = replyObj.gamedate
            homeT = replyObj.events[0].home.name
            awayT = replyObj.events[0].visitor.name

            document.getElementById("gameid").innerHTML = "Game ID: " + gameid
            document.getElementById("gamedate").innerHTML = "Game Date: " + gamedate
            document.getElementById("home").innerHTML = "Home Team: " + homeT
            document.getElementById("away").innerHTML = "Away Team: " + awayT
        }
    };
    // Send request
    http.send();
}
function getHome()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);


            var players = JSON.stringify(replyObj.events[0].home.players)
            document.getElementById("homePlayers").innerHTML = players

            for (var i = 0; i <= replyObj.events[0].home.players.length - 1; i++)
            {
                var firstname = (replyObj.events[0].home.players[i].firstname)
                var lastname = (replyObj.events[0].home.players[i].lastname)
                var name = firstname + " " + lastname
                HnameArray.push(name)
            }
            for (var i = 0; i <= replyObj.events[0].home.players.length - 1; i++)
            {
                var jersey = (replyObj.events[0].home.players[i].jersey)
                HjerseyArray.push(jersey)
            }
            for (var i = 0; i <= replyObj.events[0].home.players.length - 1; i++)
            {
                var pos = (replyObj.events[0].home.players[i].position)
                HpositionArray.push(pos)
            }
            // Get the accuracy from the JavaScript object
            document.getElementById("Hname").innerHTML = HnameArray
            document.getElementById("Hjersey").innerHTML = HjerseyArray
            document.getElementById("Hposition").innerHTML = HpositionArray
        }
    };
    // Send request
    http.send();
}
function getAway() {
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);


            var visplayers = JSON.stringify(replyObj.events[0].visitor.players)
            document.getElementById("visPlayers").innerHTML = visplayers

            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var firstname = (replyObj.events[0].visitor.players[i].firstname)
                var lastname = (replyObj.events[0].visitor.players[i].lastname)
                var name = firstname + " " + lastname
                AnameArray.push(name)
            }
            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var jersey = (replyObj.events[0].visitor.players[i].jersey)
                AjerseyArray.push(jersey)
            }
            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var pos = (replyObj.events[0].visitor.players[i].position)
                ApositionArray.push(pos)
            }

            // Get the accuracy from the JavaScript object
            document.getElementById("name").innerHTML = AnameArray
            document.getElementById("jersey").innerHTML = AjerseyArray
            document.getElementById("position").innerHTML = ApositionArray
        }
    };

    // Send request
    http.send();
}
function getEvents()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500419.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);

            var allEvents = JSON.stringify(replyObj.events)         //Gives error when ran(think file is too big)
            var events = JSON.stringify(replyObj.events[1])         //Event 0 holds game info, moments
            var moments = JSON.stringify(replyObj.events[1].moments)

            document.getElementById("e1").innerHTML = "Event #2: " + events
            document.getElementById("m1").innerHTML = "All moments for E2: " + moments
        }
    };
    // Send request
    http.send();
}

function getDirectory()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/GameFiles";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);



            document.getElementById("files").innerHTML = "Files under directory: " + files

        }
    };
    // Send request
    http.send();
}
function getJSON()
{
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/GameFiles";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);



            document.getElementById("file").innerHTML = 0021500025.json

        }
    };
    // Send request
    http.send();
}



function awayTable() {
    var url = "http://localhost:8000";   // The URL and the port number must match the server-side
    var endpoint = "/0021500032.json";
    var http = new XMLHttpRequest();
    http.open("GET", url+endpoint, true);
    http.onreadystatechange = function() {
        var DONE = 4;       // 4 means the request is done.
        var OK = 200;       // 200 means a successful return.
        if (http.readyState == DONE && http.status == OK && http.responseText) {
            // JSON string
            replyString = http.responseText;
            // convert JSON string into JavaScript object
            replyObj = JSON.parse(replyString);


            var visplayers = JSON.stringify(replyObj.events[0].visitor.players)
            document.getElementById("visPlayers").innerHTML = visplayers

            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var firstname = (replyObj.events[0].visitor.players[i].firstname)
                var lastname = (replyObj.events[0].visitor.players[i].lastname)
                var name = firstname + " " + lastname
                AnameArray.push(name)
            }
            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var jersey = (replyObj.events[0].visitor.players[i].jersey)
                AjerseyArray.push(jersey)
            }
            for (var i = 0; i <= replyObj.events[0].visitor.players.length - 1; i++)
            {
                var pos = (replyObj.events[0].visitor.players[i].position)
                ApositionArray.push(pos)
            }
            var body = document.getElementsByTagName('body')[0];
            var tbl = document.createElement('table');
            tbl.style.width = '100%';
            tbl.setAttribute('border', '5');
            tbl.setAttribute('cellpadding', '4');
            tbl.setAttribute('cellspacing', '5');;

            var h1 = document.createElement('th');
            h1.appendChild(document.createTextNode("Name));
            h1.setAttribute('bgcolor', '##b0e0e6')
            var h2 = document.createElement('th');
            h2.appendChild(document.createTextNode("Position"));
            h2.setAttribute('bgcolor', '##b0e0e6')
            var h3 = document.createElement('th');
            h3.appendChild(document.createTextNode("Number"));
            h3.setAttribute('bgcolor', '##b0e0e6')


            var tbdy = document.createElement('tbody');
            for (var i = 0; i < AnameArray.length - 1; i++) {
                var tr = document.createElement('tr');
                var td1 = document.createElement('td');
                td1.setAttribute('bgcolor', '#ffffff')
                td1.appendChild(document.createTextNode(AnameArray[i]))
                var td2 = document.createElement('td');
                td2.setAttribute('bgcolor', '#ffffff')
                td2.appendChild(document.createTextNode(ApositionArray[i]))
                var td3 = document.createElement('td');
                td3.setAttribute('bgcolor', '#ffffff')
                td3.appendChild(document.createTextNode(AjerseyArray[i]))

                tr.appendChild(td1)
                tr.appendChild(td2)
                tr.appendChild(td3)
                tbdy.appendChild(tr);
            }
            tbl.appendChild(h1)
            tbl.appendChild(h2)
            tbl.appendChild(h3)
            tbl.appendChild(tbdy)
            body.appendChild(tbl)
            }
        };
        http.send();
}

*/





